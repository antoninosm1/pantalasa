<?php
// VINCULAMOS CLASES
require_once "Sistema.php";
require_once "Conexion_sdhybc.php";
require_once "Consultaphp.php";
require_once "Log.php";
session_start();
header( 'Content-type: text/html; charset=utf-8' );
// ESTABLECEMOS PARAMETROS DE LOG
$_SESSION['logPhp']->configuraciones[2] = '';
// LOGEAMOS INICIO
$_SESSION['logPhp']->configuraciones[1] = ' ';
$_SESSION['logPhp']->escribe_log();
$_SESSION['logPhp']->configuraciones[1] = date('Y-m-d H:i:s').'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
$_SESSION['logPhp']->escribe_log();
$_SESSION['logPhp']->configuraciones[1] = date('Y-m-d H:i:s').' INICIAMOS pruebas_php.php';
$_SESSION['logPhp']->escribe_log();
$_SESSION['logPhp']->configuraciones[1] = date('Y-m-d H:i:s').'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
$_SESSION['logPhp']->escribe_log();
$_SESSION['logPhp']->configuraciones[1] = ' ';
$_SESSION['logPhp']->escribe_log();

// REVISAMOS, BAJAMOS Y ESTABLECEMOS VARIABLES A PARTIR DE VARIABLES POST

$filtro_municipio = 1;
$filtro_localidad = 1;
$filtro_consulta = 0;
$municipio = $_POST['dato_0'];
$localidad = $_POST['dato_1'];
$posicion_inicio = $_POST['dato_2'];
$porcion = $_POST['dato_3'];
$inicial_lote = $_POST['dato_4'];
$respuestaJSON = '[';

$parametro01 = [0, [[0, "cedula.MunicipioNom", 0, $municipio, 0]], 0];
$parametro02 = [0, [[0, "cedula.LocalidadNom", 0, $localidad, 0]], 0];

$lista_parametros = [];

if ($municipio=="TODOS_REGISTROS") {
    $filtro_municipio = 0;
}
else {
    $filtro_municipio = 1;
    $lista_parametros[] = $parametro01;
    $filtro_consulta = 1;
}
if ($localidad=="TODOS_REGISTROS_L") {
    $filtro_localidad = 0;
}
else {
    $filtro_localidad = 1;
    $lista_parametros[] = $parametro02;
    $filtro_consulta = 1;
}

///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
// HACEMOS INSTANCIA DEL OBJETO Consulta PARA CONOCER LA CANTIDAD DE REGISTROS	
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
$numero_elementos = 1;
$tables = ['cedula'];
$where = [$filtro_consulta, $lista_parametros]; 
$order_order = 1;
$order_elementos = ['Cedula.ID'];
$order = [1, $order_order, $order_elementos];
$sistema = $_SESSION['Sistema'];
$status = 0;
$tipo = 1;
$limites = [0, 0, 0, 0, 0, 0];
$registros = 0;
$excel = [0, '', 0, '', '', '', '', ''];
$nombre = 'INST:: consulta_total_registros';
$configuraciones = [$numero_elementos, $tables, $where, $order, $sistema, $_SESSION['bd'], $status, $tipo, $limites, $registros, $excel, $nombre];
$codigos = ['', '', [], '', '', ''];
$elementos_campos = ['COUNT(*)'];
$elementos_nombres = ['dato_01'];
$elementos_tipos = [1];
$elementos = [$elementos_campos, $elementos_nombres, $elementos_tipos];
$consulta_total_registros_cedulas = new Consultaphp($configuraciones, $codigos, $elementos);

// EJECUTAMOS METODO construye() DEL OBJETO Consulta	
$consulta_total_registros_cedulas->construye();

// EJECUTAMOS METODO ejecuta() DEL OBJETO Consulta	
$consulta_total_registros_cedulas->ejecuta();

echo '{"registros" : "10000"}';

// LOGEAMOS TERMINO
$_SESSION['logPhp']->configuraciones[1] = ' ';
$_SESSION['logPhp']->escribe_log();
$_SESSION['logPhp']->configuraciones[1] = date('Y-m-d H:i:s').'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
$_SESSION['logPhp']->escribe_log();
$_SESSION['logPhp']->configuraciones[1] = date('Y-m-d H:i:s').' TERMINO pruebas_php.php';
$_SESSION['logPhp']->escribe_log();
$_SESSION['logPhp']->configuraciones[1] = date('Y-m-d H:i:s').'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
$_SESSION['logPhp']->escribe_log();
$_SESSION['logPhp']->configuraciones[1] = ' ';
$_SESSION['logPhp']->escribe_log();

